//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<hypersdkflutter/HyperSdkFlutterPlugin.h>)
#import <hypersdkflutter/HyperSdkFlutterPlugin.h>
#else
@import hypersdkflutter;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [HyperSdkFlutterPlugin registerWithRegistrar:[registry registrarForPlugin:@"HyperSdkFlutterPlugin"]];
}

@end
