import 'package:flutter/material.dart';
import 'package:hdfc/PaymentView.dart';
import 'package:hypersdkflutter/hypersdkflutter.dart';

void main() {
  final hypersdk = HyperSDK();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  final HyperSDK hyperSDK;
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(home: Paymentview());
  }
}
