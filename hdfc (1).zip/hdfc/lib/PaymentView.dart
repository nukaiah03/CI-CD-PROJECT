import 'package:flutter/material.dart';

class Paymentview extends StatefulWidget {
  const Paymentview({super.key});

  @override
  State<Paymentview> createState() => _PaymentviewState();
}

class _PaymentviewState extends State<Paymentview> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(child: Text("HDFC payment View")));
  }
}
